package com.example.praktek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
